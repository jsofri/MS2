//
// Created by rony on 19/01/2020.
//

#ifndef PRINT_TO_FILE_H
#define PRINT_TO_FILE_H

#include <string>
using namespace std;

class PrintToFile {
public:
    static void write(string&, string);
};


#endif //PRINT_TO_FILE_H
